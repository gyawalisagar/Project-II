<?php include_once('header.inc.php');?>

<div class="container">
  <?php if($_SESSION['user_type']=='agent'):?>
  <div class="py-5 text-center">
    <h1 class="display-5">List Property</h1>
  </div>

    <div class="col-md-8 order-md-1">

      <div class="row">
        <div class="col-9">
          <form id="listproperty_form" action="backend/listproperty.php" method="POST" enctype="multipart/form-data">
            <div class="mb-3">
              <label for="property_type">Property Type</label><br>
              <select class="form-control" name="property_type" id="property_type">
								<option value="House">House</option>
								<option value="Apartment">Apartment</option>
                <option value="Unit">Unit</option>
							</select>
            </div>

            <div class="mb-3">
              <label for="type">Rent/Sale Type</label><br>
              <select class="form-control" name="type" id="type">
								<option value="Rent">Rent</option>
								<option value="Sale">Sale</option>
							</select>
            </div>

            <div class="mb-3">
              <label for="price">Price</label>
              <input type="number" class="form-control" id="price" name="price" required>
            </div>

            <div class="mb-3">
                <label for="location">Location</label>
                <input type="text" class="form-control" id="location" name="location" required />
            </div>

            <div class="mb-3">
              <label for="bedroom">Bedroom</label><br>
              <select class="form-control" name="bedroom" id="bedroom">
								<option value="1">1</option>
								<option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
                <option value="5">5</option>
                <option value="6">6</option>
							</select>
            </div>

            <div class="mb-3">
              <label for="bathroom">Bathroom</label><br>
              <select class="form-control" name="bathroom" id="bathroom">
								<option value="1">1</option>
								<option value="2">2</option>
                <option value="3">3</option>
							</select>
            </div>

            <div class="mb-3">
                <label for="area">Area</label>
                <input type="number" class="form-control" id="area" name="area" required />
            </div>

            <div class="mb-3">
              <label for="parking">Parking</label><br>
              <select class="form-control" name="parking" id="parking">
                <option value="0">0</option>
								<option value="1">1</option>
								<option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
							</select>
            </div>

            <div class="mb-3">
                <label for="description">Description</label>
                <textarea row="5" class="form-control" id="description" name="description" required></textarea>
            </div>

              <div class="mb-3">
                  <label for="photo">Photo</label>
                  <input type="file" class="form-control" id="photo" name="photo" />
                  <label for="error" class="text-danger"><?php
                    if(isset($_GET['error'])){
                      echo $_GET['error'];
                    }?>
                  </label>
              </div>



            <hr class="mb-4">
            <div class="row">
              <button class="btn btn-primary btn-block" type="submit">List Property</button>
            </div>
            <hr class="mb-4">
          </form>
        </div>

      </div><!--close row-->
    </div><!--close col main-->
  <?php else:?>
      <h4 class="text-danger">You don't have access to this page.</h4>
  <?php endif?>
</div><!--close container-->

<?php include_once('footer.inc.php');?>
