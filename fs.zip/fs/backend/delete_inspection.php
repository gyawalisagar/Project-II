<?php
    include 'db_conn.php';
    $errors=array();

	if($_POST){
        $delete_inspection_time_ids= $_POST['delete_inspection_time_ids'];
        $delete_ids = implode(",",$delete_inspection_time_ids);

        if (count($errors) == 0) {
                $sql="DELETE FROM inspection_time WHERE id IN ($delete_ids)";
                $result=mysqli_query($mysqli,$sql);
                if($result){
                    echo true;
                    //echo "Message submitted successfully";
                }
              }
            else{
                array_push($errors, "Server Error.");
                echo $errors[0].$mysqli -> error;
        }
	}


?>
