<?php
    if(!isset($_SESSION)){
      session_start();
    }
    include 'db_conn.php';
    $errors=array();

	if($_POST){

        $property_id= mysqli_escape_string($mysqli, $_POST['ed_property_id']);
        $property_type= mysqli_escape_string($mysqli, $_POST['property_type']);
        $p_type= mysqli_escape_string($mysqli, $_POST['type']);
        $price= mysqli_escape_string($mysqli, $_POST['price']);
        $location= mysqli_escape_string($mysqli, $_POST['location']);
        $bedroom= mysqli_escape_string($mysqli, $_POST['bedroom']);
        $bathroom=mysqli_escape_string($mysqli, $_POST['bathroom']);
        $area=mysqli_escape_string($mysqli, $_POST['area']);
        $parking=mysqli_escape_string($mysqli, $_POST['parking']);
        $description=mysqli_escape_string($mysqli, $_POST['description']);
        $username= $_SESSION['username'];
        $user_id= $_SESSION['id'];

        if (count($errors) == 0) {
          $sql="UPDATE property SET type='$p_type',
                                    price='$price',
                                    location='$location',
                                    bedroom='$bedroom',
                                    bathroom='$bathroom',
                                    area='$area',
                                    parking='$parking',
                                    user_id='$user_id',
                                    description='$description',
                                    property_type='$property_type'
                                WHERE id='$property_id';";
          $result=mysqli_query($mysqli,$sql);
          if($result){
              echo true;
          }else{
            array_push($errors, "Can't update now. Please try again later");
          }
        }
            else{
                array_push($errors, "Server Error.");
                echo $errors[0].$mysqli -> error;
        }


	}



?>
