<?php
    include 'db_conn.php';
    $errors=array();

	if(isset($_POST['inspection_time'])){
        $user_id= mysqli_escape_string($mysqli, $_POST['user_id']);
        $inspection_id= mysqli_escape_string($mysqli, $_POST['inspection_time']);
        $comment= mysqli_escape_string($mysqli, $_POST['comment']);

        if (count($errors) == 0) {

                $sql="INSERT INTO book_inspection(user_id, inspection_id, comment)
                                      VALUES('$user_id', '$inspection_id', '$comment');";
                $result=mysqli_query($mysqli,$sql);
                if($result){
                    echo true;
                }
              }
            else{
                array_push($errors, "Server Error.");
                echo $errors[0].$mysqli -> error;
        }
	}
  else{
      array_push($errors, "No time slots selected");
      echo $errors[0].$mysqli -> error;
}


?>
