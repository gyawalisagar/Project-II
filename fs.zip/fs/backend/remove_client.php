<?php

    include 'db_conn.php';
    $errors=array();

	   if(isset($_POST['id'])){

          $booking_id= mysqli_escape_string($mysqli, $_POST['id']);

          if (count($errors) == 0) {
            $sql="DELETE FROM assignment WHERE book_inspection_id='$booking_id'";
            $result=mysqli_query($mysqli,$sql);
            if($result){
                echo true;
            }else{
              array_push($errors, "Can't remove now. Please try again later");
            }
          }
          else{
            array_push($errors, "Server Error.");
            echo $errors[0].$mysqli -> error;
          }

	     }



?>
