<?php

if(!isset($_SESSION)){
  session_start();
}
    include 'db_conn.php';
    $errors=array();

	if($_POST && isset($_FILES['photo'])){

        $property_type= mysqli_escape_string($mysqli, $_POST['property_type']);
        $p_type= mysqli_escape_string($mysqli, $_POST['type']);
        $price= mysqli_escape_string($mysqli, $_POST['price']);
        $location= mysqli_escape_string($mysqli, $_POST['location']);
        $bedroom= mysqli_escape_string($mysqli, $_POST['bedroom']);
        $bathroom=mysqli_escape_string($mysqli, $_POST['bathroom']);
        $area=mysqli_escape_string($mysqli, $_POST['area']);
        $parking=mysqli_escape_string($mysqli, $_POST['parking']);
        $list_date= date("Y-m-d");
        $description=mysqli_escape_string($mysqli, $_POST['description']);
        $username= $_SESSION['username'];
        $email= $_SESSION['email'];
        $user_id=$_SESSION['id'];

        $img_name=$_FILES['photo']['name'];
        $img_size=$_FILES['photo']['size'];
        $tmp_name=$_FILES['photo']['tmp_name'];
        $error=$_FILES['photo']['error'];
        $type=$_FILES['photo']['type'];

        if($error === 0){
           if($img_size>5000000){
             $em = "File too large. Accepts less than 5MB";
             header("Location: ../listproperty.php?error=$em");
           }else{
             $img_ex_lc= mb_strtolower(pathinfo($img_name, PATHINFO_EXTENSION));
             $allowed_exs = array("jpg", "jpeg", "png");
             if(in_array($img_ex_lc,$allowed_exs)){
                $new_img_name = uniqid("IMG-",true).".".$img_ex_lc;
                $img_upload_path = '../uploads/'.$new_img_name;
                move_uploaded_file($tmp_name,$img_upload_path);

                //inserting into the SQLiteDatabase

                $sql="INSERT INTO property(type, price, location, bedroom, bathroom, area, parking, user_id, photo, list_date, description, property_type)
                                      VALUES('$p_type', '$price', '$location', '$bedroom', '$bathroom', '$area', '$parking', '$user_id', '$new_img_name' ,'$list_date', '$description','$property_type');";
                $result=mysqli_query($mysqli,$sql);
                if($result){
                    header("Location: ../property.php");
                }

             }else{
               $em = "Type not supported";
               header("Location: ../listproperty.php?error=$em");
             }
           }
        }else{
          $em = "Unknown error occoured";
          header("Location: ../listproperty.php?error=$em");
        }





	}



?>
