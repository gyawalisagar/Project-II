<?php
    include 'db_conn.php';
    $errors=array();

	if($_POST){
        $property_id= mysqli_escape_string($mysqli, $_POST['property_id']);
        $date= mysqli_escape_string($mysqli, $_POST['date']);
        $time= mysqli_escape_string($mysqli, $_POST['time']);

        if (count($errors) == 0) {
                $sql="INSERT INTO inspection_time(`property_id`, `date`, `time`)
                                      VALUES('$property_id', '$date', '$time');";
                $result=mysqli_query($mysqli,$sql);
                if($result){
                    echo true;
                    //echo "Message submitted successfully";
                }
              }
            else{
                array_push($errors, "Server Error.");
                echo $errors[0].$mysqli -> error;
        }
	}


?>
