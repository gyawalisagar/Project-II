<?php
    include 'db_conn.php';
    if($_POST['property_id']){
      $property_id = mysqli_escape_string($mysqli, $_POST['property_id']);
      //echo $property_id;
      $query = "SELECT * FROM property WHERE id='$property_id'  LIMIT 1";
      $result = mysqli_query($mysqli, $query);
      $property = mysqli_fetch_assoc($result);
      echo json_encode($property);
     }
