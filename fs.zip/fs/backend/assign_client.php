<?php
    include 'db_conn.php';
    $errors=array();

	if($_POST){
        $book_inspection_id = mysqli_escape_string($mysqli, $_POST['id']);

        //$query = "SELECT I.property_id FROM book_inspection B, inspection_time I WHERE B.inspection_id = I.id";
        $check_property_query = "SELECT property_id FROM assignment A, book_inspection B, inspection_time I WHERE A.book_inspection_id = B.id AND B.inspection_id = I.id LIMIT 1";
        $result = mysqli_query($mysqli, $check_property_query);
        $property = mysqli_fetch_assoc($result);
        $status = "ASSIGNED";

        if ($property) { // if property already assgined
            array_push($errors, "Property Already assigned to others");
        }

        if ((count($errors) == 0)) {

                $sql="INSERT INTO assignment(book_inspection_id, status)
                                      VALUES('$book_inspection_id','$status');";
                $result=mysqli_query($mysqli,$sql);
                if($result){
                    echo true;
                    // "Assigned Client for the property";
                }
              }
            else{
                array_push($errors, "Server Error.");
                echo $errors[0].$mysqli -> error;
        }
	}


?>
