<?php
    include 'db_conn.php';
    $errors=array();

	if($_POST){
        $email= mysqli_escape_string($mysqli, $_POST['email']);

        $email_check_query = "SELECT * FROM newsletter WHERE email='$email' LIMIT 1";
        $result = mysqli_query($mysqli, $email_check_query);
        $subscriber = mysqli_fetch_assoc($result);

        if ($subscriber) { // if subscriber exists
            array_push($errors, "Already Subscribed");
        }

        if (count($errors) == 0) {

                $sql="INSERT INTO newsletter(email)
                                      VALUES('$email');";
                $result=mysqli_query($mysqli,$sql);
                if($result){
                    echo true;
                }
              }
            else{
                array_push($errors, "Server Error.");
                echo $errors[0].$mysqli -> error;
        }
	}


?>
