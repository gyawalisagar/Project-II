<?php

function is_property_already_assigned(){
  $check_property_query = "SELECT property_id FROM assignment A, book_inspection B, inspection_time I WHERE A.book_inspection_id = B.id AND B.inspection_id = I.id LIMIT 1";
  $result = mysqli_query($mysqli, $check_property_query);
  $property = mysqli_fetch_assoc($result);
  $is_property_already_assigned = false;
  if ($property) { // if property already assgined
      $is_property_already_assigned = true;
  }
  return $is_property_already_assigned;
}


?>
