<?php include_once('header.inc.php')?>
<?php
    require('backend/db_conn.php');
    $user_id=$_SESSION['id'];
    $query="SELECT * FROM user WHERE id='$user_id';";
    $result=mysqli_query($mysqli,$query);
    $user_details=mysqli_fetch_assoc($result);
    $user_name=$user_details['name'];
    $email=$user_details['email'];
    $phone=$user_details['phone'];
    $address=$user_details['address'];
    $type=$user_details['type'];
?>
<div class="container">
    <div class="main-body">
          <div class="row gutters-sm">
            <div class="col-md-4 mb-3">
              <div class="card">
                <div class="card-body">
                  <div class="d-flex flex-column align-items-center text-center">
                    <img src="https://bootdey.com/img/Content/avatar/avatar7.png" alt="Admin" class="rounded-circle" width="150">
                    <div class="mt-3">
                      <h4><?php echo $user_name;?></h4>
                      <p class="text-secondary mb-1"><?php echo strtoupper($type);?></p>
                      <p class="text-muted font-size-sm"><?php echo $address;?></p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-8">

              <div id="profile_edit_display" class="card mb-3">
                <div class="card-body">
                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Full Name</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      <?php echo $user_name;?>
                    </div>
                  </div>
                  <hr>
                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Email</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      <?php echo $email;?>
                    </div>
                  </div>
                  <hr>
                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Phone</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      <?php echo $phone;?>
                    </div>
                  </div>
                  <hr>
                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Address</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      <?php echo $address;?>
                    </div>
                  </div>
                  <hr>
                  <div class="row">
                    <div class="col-sm-12">
                      <a id="edit_profile_button" class="btn btn-info">Edit</a>
                    </div>
                  </div>
                </div>
              </div>

              <!--Form for editing profile !-->
              <form id="profile_edit_form" style="display:none;">
                <div class="card mb-3" >
                  <div class="card-body">
                    <div class="row">
                      <div class="col-sm-3">
                        <h6 class="mb-0">Full Name</h6>
                      </div>
                      <div class="col-sm-9 text-secondary">
                        <input type="text" class="form-control" name="name" id="name" value="<?php echo $user_name;?>" required></input>
                      </div>
                    </div>
                    <hr>
                    <div class="row">
                      <div class="col-sm-3">
                        <h6 class="mb-0">Email</h6>
                      </div>
                      <div class="col-sm-9 text-secondary">
                        <input type="email" class="form-control" name="email" id="email" value="<?php echo $email;?>" required></input>
                      </div>
                    </div>
                    <hr>
                    <div class="row">
                      <div class="col-sm-3">
                        <h6 class="mb-0">Password</h6>
                      </div>
                      <div class="col-sm-9 text-secondary">
                        <input type="password" class="form-control" name="password" id="password" required></input>
                      </div>
                    </div>
                    <hr>
                    <div class="row">
                      <div class="col-sm-3">
                        <h6 class="mb-0">Phone</h6>
                      </div>
                      <div class="col-sm-9 text-secondary">
                        <input type="text" class="form-control" name="phone" id="phone" value="<?php echo $phone;?>" required></input>
                      </div>
                    </div>
                    <hr>
                    <div class="row">
                      <div class="col-sm-3">
                        <h6 class="mb-0">Address</h6>
                      </div>
                      <div class="col-sm-9 text-secondary">
                        <input type="text" class="form-control" name="address" id="address" value="<?php echo $address;?>" required></input>
                      </div>
                    </div>
                    <hr>
                    <div class="row">
                      <div class="col-sm-12">
                        <button class="btn btn-info btn-block">Submit</button>
                        <a id="cancel_edit_profile_button" class="btn btn-danger btn-block">Cancel</a>
                      </div>

                    </div>
                  </div>
              </div>
            </form>
              <!--Form for editing profile !-->

              <?php if($_SESSION['user_type']=='agent'):?>

              <p class="display-4">Properties you listed</p>

              <div class="row gutters-sm">
                <?php
                $query="SELECT id, location, type FROM property WHERE user_id='$user_id'";
                $result=mysqli_query($mysqli, $query);
                if($result){
                  while($property=mysqli_fetch_assoc($result)){
                    ?>
                    <div class="col-sm-6 mb-3">
                      <div class="card h-100">
                        <a href="property-single.php?id=<?php echo $property['id']?>">
                          <div class="card-body">
                            <h6 class="d-flex align-items-center mb-3"><i class="material-icons text-info mr-2"><?php echo $property['type']?>></i><?php echo $property['location']?></h6>
                          </div>
                        </a>
                      </div>
                    </div>
                    <?php
                  }
                }
                ?>

              </div>

              <?php endif;?>



            </div>
          </div>

        </div>
    </div>
