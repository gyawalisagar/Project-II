<h3 class="sidebar-title">Inspection Booking</h3>
<div class="sidebar-item recent-posts">

  <?php
  require('backend/db_conn.php');
  //$query="SELECT * FROM property ORDER BY list_date limit 4";
  $query="SELECT * FROM property ORDER BY list_date DESC limit 4";
  $result = mysqli_query($mysqli,$query);
  if($result){

    while($row = mysqli_fetch_array($result)) {
      $id=$row["id"];
      $type=$row["type"];
      $price=$row["price"];
      $location=$row["location"];
      $photo=$row["photo"];
      $list_date=$row["list_date"];
      $img_url = "uploads/".$photo;

      ?>
    <div class="post-item clearfix">
      <img src="<?php echo $img_url?>" alt="">
      <h4><a href="property-single.php?id=<?php echo $id?>"><?php echo $type. " $". $price . "/wk ". $location ?></a></h4>
      <time><?php echo $list_date?></time>
    </div>

    <?php
    }
  }else{
    echo"No properties";
  }
  ?>


</div><!-- End sidebar recent posts-->
