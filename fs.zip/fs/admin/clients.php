<?php include('header.inc.admin.php')?>
    <div class="wrapper">
        <?php include("navbar.php")?>
        <div id="body" class="active">
            <!-- navbar navigation component -->
            <?php include('navbar_navigation.php')?>
            <!-- end of navbar navigation -->
            <div class="content">
              <div class="container">
                <div class="row">
                    <div class="col-md-12 page-header">
                        <div class="page-pretitle">Details of all Clients</div>
                        <h2 class="page-title">Clients</h2>
                    </div>
                </div>
                <div class="row">
                  <div class="col-md-12 col-lg-12">
                      <div class="card">
                          <div class="card-header">Clients</div>
                          <div class="card-body">
                              <p class="card-title"></p>
                              <table class="table table-hover" id="dataTables-example" width="100%">
                                  <thead>
                                      <tr>
                                          <th>ID</th>
                                          <th>Name</th>
                                          <th>Email</th>
                                          <th>Phone</th>
                                          <th>Address</th>
                                          <th>Delete</th>
                                      </tr>
                                  </thead>
                                  <tbody>
                                    <?php
                                    $query="SELECT * FROM user WHERE type='client';";
                                    $result=mysqli_query($mysqli,$query);
                                    $sn = 1;
                                    while($user_details=mysqli_fetch_assoc($result)){
                                      $id= $user_details['id'];
                                      $name = $user_details['name'];
                                      $email = $user_details['email'];
                                      $phone = $user_details['phone'];
                                      $address = $user_details['address'];
                                      ?>
                                      <tr>
                                          <td><?php echo $sn?></td>
                                          <td><?php echo $name?></td>
                                          <td><?php echo $email?></td>
                                          <td><?php echo $phone?></td>
                                          <td><?php echo $address?></td>
                                          <td><button class="btn"><i class="orange fas fa-trash" onclick="deleteClient(<?php echo $id ?>)"></i></button></td>
                                      </tr>
                                      <?php
                                      $sn++;
                                    }
                                    ?>
                                  </tbody>
                              </table>
                          </div>
                      </div>
                  </div>
                </div>
              </div>
            </div>
        </div>
    </div>

    <script>
      function deleteClient(id)
      {
        //alert(id);
        $.ajax({
          type: 'POST',
          url:'backend/deleteClient.php',
          data: {id:id},
          success: function(response){
            if (response == 1){
              alert('Successfully Deleted the client');
              location.reload();
            }
            else{
              alert(response);
            }
          }

        });
      }
    </script>
  <?php include('footer.inc.admin.php')?>
