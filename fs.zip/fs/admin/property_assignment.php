<?php include('header.inc.admin.php')?>
    <div class="wrapper">
        <?php include("navbar.php")?>
        <div id="body" class="active">
            <!-- navbar navigation component -->
            <?php include('navbar_navigation.php')?>
            <!-- end of navbar navigation -->
            <div class="content">
              <div class="container">
                <div class="row">
                    <div class="col-md-12 page-header">
                        <div class="page-pretitle">Properties</div>
                        <h2 class="page-title">Properties Assigned to Clients</h2>
                    </div>
                </div>
                <div class="row">
                  <div class="col-md-12 col-lg-12">
                      <div class="card">
                          <div class="card-header">Properties</div>
                          <div class="card-body">
                              <p class="card-title"></p>
                              <table class="table table-hover" id="dataTables-example" width="100%">
                                  <thead>
                                      <tr>
                                          <th>SN</th>
                                          <th>Property</th>
                                          <th>Porperty Type</th>
                                          <th>Type</th>
                                          <th>Price</th>
                                          <th>Client Name</th>
                                          <th>Sales Agent</th>
                                      </tr>
                                  </thead>
                                  <tbody>
                                    <?php
                                    $query="SELECT p.id, p.location, p.type, p.property_type,p.price, u.name as client, (SELECT name from user where id=p.user_id) as agent
                                            FROM assignment a, book_inspection b, inspection_time i, property p, user u
                                             WHERE a.book_inspection_id = b.id AND
                                                    b.user_id = u.id AND
                                                    b.inspection_id = i.id AND
                                                    i.property_id = p.id";
                                    $result=mysqli_query($mysqli,$query);
                                    $sn = 1;
                                    while($user_details=mysqli_fetch_assoc($result)){
                                      $id = $user_details['id'];
                                      $location = $user_details['location'];
                                      $property_type = $user_details['property_type'];
                                      $type = $user_details['type'];
                                      $price = $user_details['price'];
                                      $client = $user_details['client'];
                                      $agent = $user_details['agent'];

                                      ?>
                                      <tr>
                                          <td><?php echo $sn?></td>
                                          <td><a href="../property-single.php?id=<?php echo $id;?>"><?php echo $location?></a></td>
                                          <td><?php echo $property_type?></td>
                                          <td><?php echo $type?></td>
                                          <td>$<?php echo $price?></td>
                                          <td><?php echo $client?></td>
                                          <td><?php echo $agent?></td>

                                      </tr>
                                      <?php
                                      $sn++;
                                    }
                                    ?>
                                  </tbody>
                              </table>
                          </div>
                      </div>
                  </div>
                </div>
              </div>
            </div>
        </div>
    </div>
    <?php include('footer.inc.admin.php')?>
