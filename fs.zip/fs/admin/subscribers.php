<?php include('header.inc.admin.php')?>
    <div class="wrapper">
        <?php include("navbar.php")?>
        <div id="body" class="active">
            <!-- navbar navigation component -->
            <?php include('navbar_navigation.php')?>
            <!-- end of navbar navigation -->
            <div class="content">
              <div class="container">
                <div class="row">
                    <div class="col-md-12 page-header">
                        <div class="page-pretitle">List of all Subscribers</div>
                        <h2 class="page-title">Subscribers</h2>
                    </div>
                </div>
                <div class="row">
                  <div class="col-md-12 col-lg-12">
                      <div class="card">
                          <div class="card-header">Subscribers</div>
                          <div class="card-body">
                              <p class="card-title"></p>
                              <table class="table table-hover" id="dataTables-example" width="100%">
                                  <thead>
                                      <tr>
                                          <th>SN</th>
                                          <th>Email Address</th>
                                          <th>Delete</th>
                                      </tr>
                                  </thead>
                                  <tbody>
                                    <?php
                                    $query="SELECT * FROM newsletter;";
                                    $result=mysqli_query($mysqli,$query);
                                    $sn = 1;
                                    while($user_details=mysqli_fetch_assoc($result)){
                                      $id = $user_details['id'];
                                      $email = $user_details['email'];
                                      ?>
                                      <tr>
                                          <td><?php echo $sn?></td>
                                          <td><?php echo $email?></td>
                                          <td><button class="btn" onclick=removeSubscription(<?php echo $id?>)><i class="orange fas fa-trash"></i></td>
                                      </tr>
                                      <?php
                                      $sn++;
                                    }
                                    ?>
                                  </tbody>
                              </table>
                          </div>
                      </div>
                  </div>
                </div>
              </div>
            </div>
        </div>
    </div>
    <script>
      function removeSubscription(id)
      {
        //alert(id);
        $.ajax({
          type: 'POST',
          url:'backend/removeSubscription.php',
          data: {id:id},
          success: function(response){
            if (response == 1){
              alert('Successfully Removed from the Subscription');
              location.reload();
            }
            else{
              alert(response);
            }
          }

        });
      }
    </script>
    <?php include('footer.inc.admin.php')?>
