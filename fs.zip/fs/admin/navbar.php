<nav id="sidebar" class="active">
    <div class="sidebar-header">
        <img src="assets/img/logo.png" alt="bootraper logo" class="app-logo">
    </div>
    <ul class="list-unstyled components text-secondary">
        <li>
            <a href="index.php"><i class="fas fa-bullseye"></i> Dashboard</a>
        </li>
        <li>
            <a href="clients.php"><i class="fas fa-user-friends"></i> Clients</a>
        </li>
        <li>
            <a href="properties.php"><i class="fas fa-home"></i> Properties</a>
        </li>
        <li>
            <a href="property_assignment.php"><i class="fas fa-arrows-alt-h"></i> Properties Assignment</a>
        </li>
        <li>
            <a href="messages.php"><i class="fas fa-envelope"></i> Messages</a>
        </li>
        <li>
            <a href="subscribers.php"><i class="fas fa-rocket"></i> Subscribers</a>
        </li>
        <li>
            <a href="../index.php"><i class="fas fa-globe"></i> Website</a>
        </li>
    </ul>
</nav>
