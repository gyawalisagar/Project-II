<?php
include('db_conn.php');

if($_POST){
  $id = $_POST['id'];
  $query = "DELETE FROM property WHERE id='$id';";
  $result = mysqli_query($mysqli, $query);
  if($result){
    echo true;
  }else{
    echo "Couldn't delete now";
  }

}
?>
