<?php
require("db_conn.php");
function getTotalClients(){
  global $mysqli;
  $query="SELECT COUNT(type) AS clients FROM user WHERE type='client';";
  $result=mysqli_query($mysqli,$query);
  $user_details=mysqli_fetch_assoc($result);
  return $user_details['clients'];
}

function getTotalProperty(){
  global $mysqli;
  $query="SELECT COUNT(type) AS proterties FROM property;";
  $result=mysqli_query($mysqli,$query);
  $user_details=mysqli_fetch_assoc($result);
  return $user_details['proterties'];
}

function getTotalSubscribers(){
  global $mysqli;
  $query="SELECT COUNT(id) AS subscribers FROM newsletter;";
  $result=mysqli_query($mysqli,$query);
  $user_details=mysqli_fetch_assoc($result);
  return $user_details['subscribers'];
}

function getTotalMessages(){
  global $mysqli;
  $query="SELECT COUNT(id) AS messages FROM contact;";
  $result=mysqli_query($mysqli,$query);
  $user_details=mysqli_fetch_assoc($result);
  return $user_details['messages'];
}

function getTotalPropertiesAssigned(){
  global $mysqli;
  $query="SELECT COUNT(id) AS assignments FROM assignment;";
  $result=mysqli_query($mysqli,$query);
  $user_details=mysqli_fetch_assoc($result);
  return $user_details['assignments'];
}
?>
