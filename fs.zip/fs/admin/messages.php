<?php include('header.inc.admin.php')?>
    <div class="wrapper">
        <?php include("navbar.php")?>
        <div id="body" class="active">
            <!-- navbar navigation component -->
            <?php include('navbar_navigation.php')?>
            <!-- end of navbar navigation -->
            <div class="content">
              <div class="container">
                <div class="row">
                    <div class="col-md-12 page-header">
                        <div class="page-pretitle">List of all Messages</div>
                        <h2 class="page-title">Messages</h2>
                    </div>
                </div>
                <div class="row">
                  <div class="col-md-12 col-lg-12">
                      <div class="card">
                          <div class="card-header">Messages</div>
                          <div class="card-body">
                              <p class="card-title"></p>
                              <table class="table table-hover" id="dataTables-example" width="100%">
                                  <thead>
                                      <tr>
                                          <th>ID</th>
                                          <th>Name</th>
                                          <th>Email</th>
                                          <th>Subject</th>
                                          <th>Message</th>
                                      </tr>
                                  </thead>
                                  <tbody>
                                    <?php
                                    $query="SELECT * FROM contact ORDER BY id DESC;";
                                    $result=mysqli_query($mysqli,$query);
                                    $sn = 1;
                                    while($user_details=mysqli_fetch_assoc($result)){
                                      $name =   $user_details['name'];
                                      $email = $user_details['email'];
                                      $subject = $user_details['subject'];
                                      $message = $user_details['message'];
                                      ?>
                                      <tr>
                                          <td><?php echo $sn?></td>
                                          <td><?php echo $name?></td>
                                          <td><?php echo $email?></td>
                                          <td><?php echo $subject?></td>
                                          <td><?php echo $message?></td>
                                      </tr>
                                      <?php
                                      $sn++;
                                    }
                                    ?>
                                  </tbody>
                              </table>
                          </div>
                      </div>
                  </div>
                </div>
              </div>
            </div>
        </div>
    </div>
<?php include('footer.inc.admin.php')?>
