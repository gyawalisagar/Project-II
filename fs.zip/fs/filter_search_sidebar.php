<div class="sidebar">

  <h3 class="sidebar-title">Filter Search</h3>
  <div class="sidebar-item filter-search-form">
    <form action="property.php" method="post">
      <div class="form-group">
        <label for="type">Type</label>
        <select class="form-control" name="type" id="type">
          <option value="Rent">Rent</option>
          <option value="Sale">Sale</option>
        </select>
      </div>
      <div class="form-group">
        <label for="property-type">Property Type</label>
        <select class="form-control" name="property-type" id="property-type">
          <option value="Unit">Unit</option>
          <option value="Apartment">Apartment</option>
          <option value="House">House</option>
        </select>
      </div>
      <div class="form-group">
        <label for="location">Location</label>
        <select class="form-control" name="location" id="location">
          <option value="NSW">New South Wales</option>
          <option value="VIC">Victoria</option>
          <option value="QLD">Queensland</option>
          <option value="SA">South Australia</option>
          <option value="WA">Western Australia</option>
          <option value="TAS">Tasmania</option>
        </select>
      </div>

      <div class="form-group">
        <label for="min-price">Minimum Price</label><br>
        <select class="form-control" name="min-price" id="min-price">
          <option value="100">100</option>
          <option value="150">150</option>
          <option value="200">200</option>
          <option value="250">250</option>
          <option value="300">300</option>
          <option value="350">350</option>
          <option value="400">400</option>
        </select>
      </div>
      <div class="form-group">
        <label for="max-price">Maximum Price</label><br>
        <select class="form-control" name="max-price" id="max-price">
          <option value="100">100</option>
          <option value="150">150</option>
          <option value="200">200</option>
          <option value="250">250</option>
          <option value="300">300</option>
          <option value="350">350</option>
          <option value="400">400</option>
          <option value="500">500</option>
          <option value="600">600</option>
        </select>
      </div>

      <div class="form-group">
        <label for="min-bed">Minimum Bedroom</label><br>
        <select class="form-control" name="min-bed" id="min-bed">
          <option value="1">1</option>
          <option value="2">2</option>
          <option value="3">3</option>
          <option value="4">4</option>
          <option value="5">5</option>
          <option value="6">6</option>
        </select>
      </div>
      <div class="form-group">
        <label for="max-park">Maximum Bedroom</label><br>
        <select class="form-control" name="max-bed" id="max-bed">
          <option value="1">1</option>
          <option value="2">2</option>
          <option value="3">3</option>
          <option value="4">4</option>
          <option value="5">5</option>
          <option value="6">6</option>
        </select>
      </div>

      <div class="form-group">
        <label for="min-bath">Minimum Bathroom</label><br>
        <select class="form-control" name="min-bath" id="min-bath">
          <option value="1">1</option>
          <option value="2">2</option>
          <option value="3">3</option>
          <option value="4">4</option>
        </select>
      </div>
      <div class="form-group">
        <label for="max-bath">Maximum Bathroom</label><br>
        <select class="form-control" name="max-bath" id="max-bath">
          <option value="1">1</option>
          <option value="2">2</option>
          <option value="3">3</option>
          <option value="4">4</option>
        </select>
      </div>

      <div class="form-group">
        <label for="min-park">Minimum Parking</label><br>
        <select class="form-control" name="min-park" id="min-park">
          <option value="0">0</option>
          <option value="1">1</option>
          <option value="2">2</option>
          <option value="3">3</option>
          <option value="4">4</option>
        </select>
      </div>
      <div class="form-group">
        <label for="max-park">Maximum Parking</label><br>
        <select class="form-control" name="max-park" id="max-park">
          <option value="0">0</option>
          <option value="1">1</option>
          <option value="2">2</option>
          <option value="3">3</option>
          <option value="4">4</option>
        </select>
      </div>



      <button class="btn btn-lg btn-primary" type="submit">Search <i class="bi bi-search"></i></button>
    </form>
  </div>
</div>
