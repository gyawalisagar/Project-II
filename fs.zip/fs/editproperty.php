<?php include_once('header.inc.php');
include 'backend/db_conn.php';?>

<div class="container">
  <?php if($_SESSION['user_type']=='agent'):?>
  <div class="py-5 text-center">
    <h1 class="display-5">Edit / Delete Property</h1>
  </div>

  <div class="mb-3">
    <label for="edit_property_id">Select the property from the list below</label><br>
    <select class="form-control" name="edit_property_id" id="edit_property_id">
      <option selected="selected" disabled>Select Property</option>
      <?php
        $query="SELECT * FROM property";
        $result = mysqli_query($mysqli,$query);
        while($row = mysqli_fetch_array($result)) {
          $id = $row['id'];
          $location = $row['location'];
      ?>
      <option value="<?php echo $id?>"><?php echo $location?></option>

      <?php } ?>
    </select>
  </div>

    <div class="col-md-8 order-md-1" id="edit_property_form_div" style="display:none">

      <div class="row">
        <div class="col-9">
          <form id="editproperty_form" method="POST">
            <input type="hidden" name="ed_property_id" id="ed_property_id" value="">

            <div class="mb-3">
              <label for="property_type">Property Type</label><br>
              <select class="form-control" name="property_type" id="edit_property_type">
								<option value="House">House</option>
								<option value="Apartment">Apartment</option>
                <option value="Unit">Unit</option>
							</select>
            </div>

            <div class="mb-3">
              <label for="type">Type</label><br>
              <select class="form-control" name="type" id="edit_type">
								<option value="Rent">Rent</option>
								<option value="Sale">Sale</option>
							</select>
            </div>

            <div class="mb-3">
              <label for="price">Price</label>
              <input type="number" class="form-control" id="edit_price" name="price" required>
            </div>

            <div class="mb-3">
                <label for="location">Location</label>
                <input type="text" class="form-control" id="edit_location" name="location" required />
            </div>

            <div class="mb-3">
              <label for="bedroom">Bedroom</label><br>
              <select class="form-control" name="bedroom" id="edit_bedroom">
								<option value="1">1</option>
								<option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
                <option value="5">5</option>
                <option value="6">6</option>
							</select>
            </div>

            <div class="mb-3">
              <label for="bathroom">Bathroom</label><br>
              <select class="form-control" name="bathroom" id="edit_bathroom">
								<option value="1">1</option>
								<option value="2">2</option>
                <option value="3">3</option>
							</select>
            </div>

            <div class="mb-3">
                <label for="area">Area</label>
                <input type="number" class="form-control" id="edit_area" name="area" required />
            </div>

            <div class="mb-3">
              <label for="parking">Parking</label><br>
              <select class="form-control" name="parking" id="edit_parking">
                <option value="0">0</option>
								<option value="1">1</option>
								<option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
							</select>
            </div>

            <div class="mb-3">
                <label for="description">Description</label>
                <textarea row="5" class="form-control" id="edit_description" name="description" required></textarea>
            </div>

            <hr class="mb-4">
            <div class="row">
              <button class="btn btn-primary btn-block" type="submit">Edit Property</button>
            </div>

            <hr class="mb-4">
          </form>
        </div>

      </div><!--close row-->
    </div><!--close col main-->

    <div id="delete_property_div" style="display:none">
      <form id="delete_property" method="POST">
        <input type="hidden" name="dl_property_id" id="dl_property_id" value="">
        <button class="btn btn-danger btn-block" type="submit">Delete Property</button>
      </form>
    </div>


  <?php else:?>
      <h4 class="text-danger">You don't have access to this page.</h4>
  <?php endif?>
</div><!--close container-->

<?php include_once('footer.inc.php');?>
