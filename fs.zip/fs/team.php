<!-- ======= Team Section ======= -->
<section id="team" class="team">

  <div class="container" data-aos="fade-up">

    <header class="section-header">
      <h2>Agents</h2>
      <p>Our hard working Agents</p>
    </header>

    <div class="row gy-4">

      <div class="col-lg-3 col-md-6 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="100">
        <div class="member">
          <div class="member-img">
            <img src="assets/img/team/agent1.jpeg" class="img-fluid" alt="">
          </div>
          <div class="member-info">
            <h4>Sagar Gyawali</h4>
            <span>Agent</span>
            <p></p>
          </div>
        </div>
      </div>

      <div class="col-lg-3 col-md-6 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="200">
        <div class="member">
          <div class="member-img">
            <img src="assets/img/team/agent2.jpeg" class="img-fluid" alt="">
          </div>
          <div class="member-info">
            <h4>Dipesh Bhandari</h4>
            <span>Agent</span>
            <p></p>
          </div>
        </div>
      </div>

      <div class="col-lg-3 col-md-6 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="300">
        <div class="member">
          <div class="member-img">
            <img src="assets/img/team/agent3.jpeg" class="img-fluid" alt="">
          </div>
          <div class="member-info">
            <h4>Krishna Kandel</h4>
            <span>Agent</span>
            <p></p>
          </div>
        </div>
      </div>

      <div class="col-lg-3 col-md-6 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="400">
        <div class="member">
          <div class="member-img">
            <img src="assets/img/team/agent4.jpeg" class="img-fluid" alt="">
          </div>
          <div class="member-info">
            <h4>Bishal Parajuli</h4>
            <span>Agent</span>
            <p></p>
          </div>
        </div>
      </div>

      <div class="col-lg-3 col-md-6 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="400">
        <div class="member">
          <div class="member-img">
            <img src="assets/img/team/agent5.jpeg" class="img-fluid" alt="">
          </div>
          <div class="member-info">
            <h4>Raman Bhakta Shrestha</h4>
            <span>Agent</span>
            <p></p>
          </div>
        </div>
      </div>

      <div class="col-lg-3 col-md-6 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="400">
        <div class="member">
          <div class="member-img">
            <img src="assets/img/team/agent6.jpeg" class="img-fluid" alt="">
          </div>
          <div class="member-info">
            <h4>Muhammad Walled Akram</h4>
            <span>Agent</span>
            <p></p>
          </div>
        </div>
      </div>

    </div>

  </div>

</section><!-- End Team Section -->
