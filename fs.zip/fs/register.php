<?php include_once('header.inc.php');?>
<section id="contact" class="contact">

  <div class="container" data-aos="fade-up">

    <header class="section-header">
      <p>Register</p>
    </header>

    <div class="row gy-4">

      <div class="col-lg-8">
        <form id="register_form" class="php-email-form">
          <div class="row gy-4">

            <div class="col-md-12">
              <input type="text" name="name" class="form-control" placeholder="Your Full Name" required>
            </div>

            <div class="col-md-12">
              <input type="email" class="form-control" name="email" placeholder="Your Email" required>
            </div>

            <div class="col-md-12">
              <input type="text" name="phone" class="form-control" placeholder="Phone Number" required>
            </div>

            <div class="col-md-12">
              <input type="password" class="form-control" name="password" placeholder="Password" required>
            </div>

            <div class="col-md-12">
              <input type="password" class="form-control" name="cpassword" placeholder="Confirm Password" required>
            </div>

            <div class="col-md-12">
              <input type="text" name="address" class="form-control" placeholder="Address" required>
            </div>

            <div class="col-md-12">
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="type" value="client">
                <label class="form-check-label" for="inlineRadio1">Client</label>
              </div>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="type" value="agent">
                <label class="form-check-label" for="inlineRadio2">Agent</label>
              </div>
            </div>

            <div class="col-md-12">
              <label for="info">Already have an account? <a href="login.php"> Click Here</a></label>
            </div>

            <div class="col-md-12 text-center">
              <button type="submit">Register</button>
            </div>

          </div>
        </form>

      </div>

    </div>

  </div>

</section><!-- End Contact Section -->
<?php include_once('footer.inc.php');?>
