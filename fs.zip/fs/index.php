<?php

      include_once('header.inc.php');

      include_once('canvas.php');?>

  <main id="main">

    <?php
          include_once('about.php');

          include_once('team.php');

          include_once('contact.php');
    ?>

  </main><!-- End #main -->

  <?php include_once('footer.inc.php');?>
