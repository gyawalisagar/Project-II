<?php include_once('header.inc.php');
      require('backend/db_conn.php');?>
<div class="container">
  <div class="py-5 text-center">
    <h1 class="display-5">Set Inspection for the property</h1>
  </div>

    <div class="col-md-8 order-md-1">

      <div class="row">
        <div class="col-9">
          <form id="set_inspection_form">
            <div class="mb-3">
              <label for="property_id">Select Property</label><br>
              <select class="form-control" name="property_id" id="property_id">
                <?php
                  $query="SELECT * FROM property";
                  $result = mysqli_query($mysqli,$query);
                  while($row = mysqli_fetch_array($result)) {
                    $id = $row['id'];
                    $location = $row['location'];
                ?>
								<option value="<?php echo $id?>"><?php echo $location?></option>

                <?php } ?>
							</select>
            </div>

            <div class="mb-3">
                <label for="date">Date</label>
                <input type="date" class="form-control" id="date" name="date" required />
            </div>

            <div class="mb-3">
                <label for="time">Time</label>
                <input type="time" class="form-control" id="time" name="time" required />
            </div>


            <hr class="mb-4">
            <div class="row">
              <button class="btn btn-primary btn-block" type="submit">Set Inspection</button>
            </div>
            <hr class="mb-4">
          </form>
        </div>

      </div><!--close row-->
    </div><!--close col main-->
</div><!--close container-->
<?php include_once('footer.inc.php');?>
