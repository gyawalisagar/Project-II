-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Aug 13, 2021 at 03:29 AM
-- Server version: 5.7.26
-- PHP Version: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `property`
--

-- --------------------------------------------------------

--
-- Table structure for table `book_inspection`
--

DROP TABLE IF EXISTS `book_inspection`;
CREATE TABLE IF NOT EXISTS `book_inspection` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) DEFAULT NULL,
  `inspection_id` int(10) DEFAULT NULL,
  `comment` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `book_inspection`
--

INSERT INTO `book_inspection` (`id`, `user_id`, `inspection_id`, `comment`) VALUES
(1, 2, 3, 'a'),
(5, 3, 6, 'asas'),
(4, 3, 4, 'asas');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

DROP TABLE IF EXISTS `contact`;
CREATE TABLE IF NOT EXISTS `contact` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `message` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `name`, `email`, `subject`, `message`) VALUES
(1, 'Prashant Pokhrel', 'prashantpokhrel15@gmail.com', 'Property', 'i want to buy a property'),
(2, 'Bimal Shrestha', 'bimalstha101@gmail.com', 'asa', 'asas'),
(3, '', '', '', 'a'),
(4, '', '', '', 'a');

-- --------------------------------------------------------

--
-- Table structure for table `inspection_time`
--

DROP TABLE IF EXISTS `inspection_time`;
CREATE TABLE IF NOT EXISTS `inspection_time` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `property_id` int(10) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `time` time DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `inspection_time`
--

INSERT INTO `inspection_time` (`id`, `property_id`, `date`, `time`) VALUES
(1, 12, '2021-08-11', '14:15:00'),
(2, 12, '2021-08-11', '15:15:00'),
(3, 12, '2021-08-16', '17:00:00'),
(4, 13, '2021-08-18', '17:11:00'),
(7, 13, '2021-08-14', '15:00:00'),
(6, 13, '2021-08-18', '17:15:00'),
(8, 17, '2021-08-14', '15:00:00'),
(9, 15, '2021-08-12', '14:30:00');

-- --------------------------------------------------------

--
-- Table structure for table `newsletter`
--

DROP TABLE IF EXISTS `newsletter`;
CREATE TABLE IF NOT EXISTS `newsletter` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `email` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `newsletter`
--

INSERT INTO `newsletter` (`id`, `email`) VALUES
(1, 'prashant@gmail.com'),
(2, 'prashant1@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `property`
--

DROP TABLE IF EXISTS `property`;
CREATE TABLE IF NOT EXISTS `property` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `type` varchar(20) NOT NULL,
  `price` int(10) NOT NULL,
  `location` varchar(100) NOT NULL,
  `bedroom` int(5) NOT NULL,
  `bathroom` int(5) NOT NULL,
  `area` decimal(10,2) NOT NULL,
  `parking` int(5) NOT NULL,
  `user_email` varchar(50) DEFAULT NULL,
  `photo` varchar(100) DEFAULT NULL,
  `list_date` date DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `property`
--

INSERT INTO `property` (`id`, `type`, `price`, `location`, `bedroom`, `bathroom`, `area`, `parking`, `user_email`, `photo`, `list_date`, `description`) VALUES
(12, 'Rent', 410, '14 Coastlands Place Port Macquarie NSW 2444', 4, 2, '765.00', 3, 'prashant@gmail.com', 'IMG-610e631e665447.08252232.jpg', '2021-08-07', 'Stunning hilltop mansion with sweeping ocean views\r\nAn absolute masterpiece in fine contemporary excellence; set proudly in an exclusive hilltop cul-de-sac this magnificent air conditioned home impresses with its innovative design, expansive interiors, premium fitments and private centralised swimming pool.'),
(13, 'Rent', 670, '27 Namatjira Court Broadbeach Waters QLD 4218', 3, 2, '784.00', 3, 'haku@gmail.com', 'IMG-610e636740bc21.59602358.jpg', '2021-08-07', 'A marvel of modern coastal opulence is yours to savour with this exquisite 642m2 masterpiece. Custom-built to perfection on a prime 912m2 Main River block, not only does it maximise iconic skyline and river vistas, but this unrivalled north-facing entertainer shines with bespoke design elements which epitomise timeless luxury. Blessed with breathtaking features, these include a 5.8m void over the sprawling and sophisticated living and dining zone, with picture windows to ensure an abundance of sunshine cascades in. '),
(14, 'Rent', 580, '18 The Anchorage Port Macquarie NSW 2444', 2, 1, '522.00', 1, 'haku@gmail.com', 'IMG-610e63ad8ed377.16871083.jpg', '2021-08-07', 'Perfectly designed for both intimate and large scale soirees all year round with its effortless open plan design and stunning finishes including bulk head feature ceiling with recessed LED dimmable lights, discrete in-wall speakers and elevated formal dining area. Enjoy exquisite water views from the kitchen and take in the raised 180mm stone bench, butlers pantry and abundance of storage solutions.'),
(15, 'Rent', 590, '35-39 William Street Roseville NSW 2069', 4, 2, '680.00', 3, 'haku@gmail.com', 'IMG-610e63e5106d73.81973628.jpg', '2021-08-07', 'Highlights of this residence are the new designer kitchen, the striking architectural entertainer\'s pavilion by the pool, the high ceilings and decadent bathrooms and garden lighting by \'Gardens at Night\'. Every modern feature has been incorporated from C-bus automation to CCTV security. An exceptional property in every aspect, it enjoys a family-friendly setting that is moments to the rail, village, Roseville Public School, Beauchamp Park and Chatswood\'s shopping and dining.'),
(16, 'Sale', 300000, '149 Friday Hut Road Coorabell NSW 2479', 3, 2, '654.00', 1, 'haku@gmail.com', 'IMG-610e6447cdc531.16095940.jpg', '2021-08-07', 'A stunningly beautiful property - known to locals as \'Sunnyview\' due to its ideal northeast aspect - with sweeping panoramic views over the Byron Bay hinterland. Treasured for generations by a local family, \'Sunnyview\' is on the market for the first time in nearly 70 years. Offering 40 lush acres with deep fertile alluvial soil, crystal clear creek running along the eastern boundary and fresh sea breezes, this inspiring lifestyle property sits in the heart of one of the north coast\'s most desirable blue-ribbon locations.'),
(21, 'Sale', 515000, '16 Hortus Place, Newnham, TAS, 7248', 4, 1, '321.00', 3, 'prashant@gmail.com', 'IMG-611345faeaffa1.98451275.jpg', '2021-08-11', 'Stunning House in rent with all built in features.');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(100) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `address` varchar(100) NOT NULL,
  `type` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `password`, `phone`, `address`, `type`) VALUES
(1, 'Prashant Pokhrel', 'prashantpokhrel15@gmail.com', '$2y$10$t8ssAhpTuOn1VdVwzfMt0OYWrPZUSEzVd31fxoqD..KVKGnpLIxqS', '+61405845199', 'Unit 5/ 78-80 Pitt Street', 'client'),
(2, 'Haku Kale', 'haku@gmail.com', '$2y$10$utqeSKtsl/jZHpV5FydfqOdwUILOhuZe8txMGoonnl/gK7bLGoHBC', '12123123123', '123 address', 'agent'),
(3, 'Prahant', 'prashant@gmail.com', '$2y$10$UKaw/fVUT/eaNtUz/Zpc9OasLJhLZOjH/HcsxsED.iv7PXvLBzIMu', '123456789', '12 Helen Street Kogarah', 'agent'),
(4, 'Surya Subedi', 'surya@gmail.com', '$2y$10$MA5udgjm96BOEJljqTckoOuQFJScb5JOxT0dcNIWv3zotDMfh9m1y', '0405245085', '2/122 Quarantine Road', 'client'),
(5, 'Dipesh Bhandari', 'dipesh@gmail.com', '$2y$10$3hzChJw4hY0LgULW8ibYt.wlvzJPdLOnErM3BHt.zXvpemLSd5egO', '1234512345', '19 Empress Street', 'client'),
(6, 'Sagar Gyawali', 'sagar@gmail.com', '$2y$10$HHDnMlxPvYtKvw/Wbf5AbO.R2logwBWpUkqH7Gk/eKxcf.rxP8/GC', '12312312321', 'my address', 'agent'),
(7, 'Bimal Shrestha', 'bimals@gmail.com', '$2y$10$/mPEI65cgQFv9EsN7XaDHu/KHabVm.T9dGwi8xo1BwJhvGeOYp3xq', '0414052562', '5/47 Welman Street', 'client');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
