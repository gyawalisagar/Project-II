$(document).ready(function() {
///////////////////edit_property get details in the form
  $( "#edit_property_id" ).change(function() {
    var property_id = $( "#edit_property_id" ).val();
    //console.log(property_id);
    $("#ed_property_id").attr("value",property_id);
    $("#dl_property_id").attr("value",property_id);
    $('#delete_property_div').show();
    $.ajax({
      type: "POST",
      url: './backend/edit_property_details.php',
      data: {property_id:property_id},
      success: function(response)
      {
          var property = JSON.parse(response);
          $('#edit_property_form_div').show();
          $("#edit_property_type").val(property['property_type']);
          $("#edit_type").val(property['type']);
          $("#edit_price").attr("value",property['price']);
          $("#edit_location").attr("value",property['location']);
          $("#edit_bedroom").val(property['bedroom']);
          $("#edit_bathroom").val(property['bathroom']);
          $("#edit_area").attr("value",property['area']);
          $("#edit_parking").val(property['parking']);
          $("#edit_description").val(property['description']);
      }
  });
  });


///////////////contact
$('#contact_form').submit(function(e) {
  e.preventDefault();
  console.log($(this).serialize());
  $.ajax({
    type: "POST",
    url: './backend/contact.php',
    data: $(this).serialize(),
    success: function(response)
    {
        if (response == true) {
          // alert("Message Successfully Sent");
          Swal.fire(
            'Message Successfully Sent!',
            '',
            'success'
          );
        }
        else {
          Swal.fire(response);
        }
    }
});
});

///////////////newsletter
$('#newsletter_form').submit(function(e) {
  e.preventDefault();
  console.log($(this).serialize());
  $.ajax({
    type: "POST",
    url: './backend/newsletter.php',
    data: $(this).serialize(),
    success: function(response)
    {
        if (response == true) {
          // alert("Message Successfully Sent");
          Swal.fire(
            'Successfully Subscribed!',
            '',
            'success'
          );
        }
        else {
          Swal.fire(response);
        }
    }
});
});


////////////////login
$('#login_form').submit(function(e) {
  e.preventDefault();
  console.log($(this).serialize());
  $.ajax({
    type: "POST",
    url: './backend/login.php',
    data: $(this).serialize(),
    success: function(response)
    {
        if (response == true) {
           alert("Login Successfull");
          window.location = 'index.php';
        }
        else {
          Swal.fire(response);
        }
    }
});
});


////////////////register
$('#register_form').submit(function(e) {
  e.preventDefault();
  console.log($(this).serialize());
  $.ajax({
    type: "POST",
    url: './backend/register.php',
    data: $(this).serialize(),
    success: function(response)
    {
        if (response == true) {
          alert("Registration Successfull. Please login to continue");
          window.location = 'login.php';
        }
        else {
          Swal.fire(response);
        }
    }
});
});


///////////////book_inspection
$('#book_inspection').submit(function(e) {
  e.preventDefault();
  console.log($(this).serialize());
  $.ajax({
    type: "POST",
    url: './backend/book_inspection.php',
    data: $(this).serialize(),
    success: function(response)
    {
        if (response == true) {
          // alert("Message Successfully Sent");
          Swal.fire(
            'Successfully Booked for Inspection!',
            '',
            'success'
          );
        }
        else {
          Swal.fire(response);
        }
    }
});
});


///////////////set_inspection_time
$('#set_inspection_form').submit(function(e) {
  e.preventDefault();
  console.log($(this).serialize());
  $.ajax({
    type: "POST",
    url: './backend/set_inspection.php',
    data: $(this).serialize(),
    success: function(response)
    {
        if (response == true) {
          // alert("Message Successfully Sent");
          Swal.fire(
            'Inspection Added Successfully!',
            '',
            'success'
          );
        }
        else {
          Swal.fire(response);
        }
    }
});
});


///////////////editproperty
$('#editproperty_form').submit(function(e) {
  e.preventDefault();
  console.log($(this).serialize());
  $.ajax({
    type: "POST",
    url: './backend/editproperty.php',
    data: $(this).serialize(),
    success: function(response)
    {
        if (response == true) {
          Swal.fire(
            'Edited Successfully!',
            '',
            'success'
          );
          //window.reload();
        }
        else {
          Swal.fire(response);
        }
    }
});
});

///////////////deleteproperty
$('#delete_property').submit(function(e) {
  e.preventDefault();
  console.log($(this).serialize());
  $.ajax({
    type: "POST",
    url: './backend/deleteproperty.php',
    data: $(this).serialize(),
    success: function(response)
    {
      //alert(response)
        if (response == true) {
          Swal.fire(
            'Deleted Successfully!',
            '',
            'success'
          );
          location.reload();
        }
        else {
          Swal.fire(response);
        }
    }
});
});



/////////////edit_profile_button_click
$( "#edit_profile_button" ).on( "click", function() {
  //alert("Hello");
  $("#profile_edit_display").hide();
  $("#profile_edit_form").show();
});

/////////////edit_profile_button_click
$( "#cancel_edit_profile_button" ).on( "click", function() {
  //alert("Hello");
  $("#profile_edit_display").show();
  $("#profile_edit_form").hide();
});


///////////////editprofile
$('#profile_edit_form').submit(function(e) {
  e.preventDefault();
  console.log($(this).serialize());
  $.ajax({
    type: "POST",
    url: './backend/editprofile.php',
    data: $(this).serialize(),
    success: function(response)
    {
        if (response == true) {
          Swal.fire(
            'Edited Successfully!',
            '',
            'success'
          );
          location.reload();
        }
        else {
          Swal.fire(response);
        }
    }
});
});

/////////////////////////

///////////////set_inspection_time
$('#delete_inspection_form').submit(function(e) {
  e.preventDefault();
  console.log($(this).serialize());
  $.ajax({
    type: "POST",
    url: './backend/delete_inspection.php',
    data: $(this).serialize(),
    success: function(response)
    {
        if (response == true) {
          Swal.fire(
            'Inspection(s) Deleted Successfully!',
            '',
            'success'
          );
          location.reload();
        }
        else {
          Swal.fire(response);
        }
    }
});
});


/////////////////assign property to client
  $(".btn-assign-client").click(function(){
    var id = $(this).attr('id');
    //alert(id);
    $.ajax({
      type: "POST",
      url: './backend/assign_client.php',
      data: {id:id},
      success: function(response)
      {
          if (response == true) {
            Swal.fire(
              'Property Successfully ASSIGNED',
              '',
              'success'
            );
            location.reload();
          }
          else {
            Swal.fire(response);
          }
      }
    });
  });

  /////////////////remove property from client
    $(".btn-remove-client").click(function(){
      var id = $(this).attr('id');
      //alert(id);
      $.ajax({
        type: "POST",
        url: './backend/remove_client.php',
        data: {id:id},
        success: function(response)
        {
            if (response == true) {
              Swal.fire(
                'Successfully removed Client from the property',
                '',
                'success'
              );
              location.reload();
            }
            else {
              Swal.fire(response);
            }
        }
      });
    });


});
