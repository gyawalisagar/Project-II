<div class="blog-comments">
  <div class="reply-form">
    <h4>Avaialbe Inspecion Dates</h4>
    <form id="delete_inspection_form" method="POST">
      <div class="row">
        <p>Select Available Time Slots to delete an inspection </p>
        <div class="col form-group">
          <!--loop this-->
          <?php
            $query="SELECT * FROM inspection_time WHERE property_id='$id'";
            $result = mysqli_query($mysqli,$query);
              while($row = mysqli_fetch_array($result)) {
                $inspection_id = $row['id'];
                $date = $row['date'];
                $time = $row['time'];
          ?>

          <div class="form-check">
            <input class="form-check-input" type="checkbox" name="delete_inspection_time_ids[]" value="<?php echo $inspection_id?>">
            <label class="form-check-label" for="delete_inspection_time<?php echo $inspection_id?>"><?php echo $date . " - " . $time?></label>
          </div>

        <?php } ?>
          <!--end loop-->
        </div>
      </div>

      <input type="hidden" name="user_id" value="<?php echo $_SESSION['id']?>"/>

        <button type="submit" class="btn btn-danger btn-lg">Delete Inspection(s) </button>

      <a class="btn btn-success btn-lg" href="set_inspection.php">Set Inspection Time</a>

    </form>
  </div>

</div><!-- End blog comments -->
