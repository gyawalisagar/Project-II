<?php
if(isset($_SESSION['user_type'])){
  if($_SESSION['user_type']=="client"){ ?>
  <div class="sidebar">
    <h3 class="sidebar-title">Your Booking</h3>
    <div class="sidebar-item">

      <?php
      $check_property_query = "SELECT I.property_id, B.user_id FROM assignment A, book_inspection B, inspection_time I WHERE A.book_inspection_id = B.id AND B.inspection_id = I.id LIMIT 1";
      $result = mysqli_query($mysqli, $check_property_query);
      $property = mysqli_fetch_assoc($result);
      $is_property_already_assigned = false;
      if ($property) { // if property already assgined
        $assigned_user_id = $property['user_id'];
        $is_property_already_assigned = true;
      }
      $logged_user_id = $_SESSION['id'];
      $query="SELECT
                U.name AS user_name,
                T.time,
                T.date,
                T.id AS inspection_id,
                B.id AS booking_id,
                B.comment AS comment,
                P.id AS property_id,
                U.id AS user_id
              FROM inspection_time T,
                book_inspection B,
                property P,
                user U
              WHERE  T.property_id = P.id
                AND B.inspection_id = T.id
                AND B.user_id = U.id
                AND P.id='$id'
                AND U.id='$logged_user_id'";
      $result = mysqli_query($mysqli,$query);
      if($result){ $count=1;?>
        <table class="table">
          <thead>
            <tr>
              <th scope="col">#</th>
              <th scope="col">Name</th>
              <th scope="col">Date</th>
              <th scope="col">Time</th>
              <th scope="col">Comments</th>
            </tr>
          </thead>
          <tbody>
        <?php

        while($row = mysqli_fetch_array($result)) {
          $user_name=$row["user_name"];
          $time=$row["time"];
          $date=$row["date"];
          $user_id=$row["user_id"];
          $comment = $row["comment"];
          $book_inspection_id = $row["booking_id"];
          ?>
          <tr>
            <th scope="row"><?php echo $count?></th>
            <td><?php echo $user_name?></td>
            <td><?php echo $date?></td>
            <td><?php echo $time?></td>
            <td><?php echo $comment?></td>

          </tr>
        <?php
        $count++;
      }?>
        </tbody>
      </table>

      <?php
    }else{
        echo"No properties";
      }
      ?>


    </div><!-- sidebar item-->
  </div><!-- sidebar -->
  <?php
  }
}
?>
