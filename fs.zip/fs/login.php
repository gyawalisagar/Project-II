<?php include_once('header.inc.php');?>
<section id="contact" class="contact">

  <div class="container" data-aos="fade-up">

    <header class="section-header">
      <p>Login</p>
    </header>

    <div class="row gy-4">

      <div class="col-lg-8">
        <form id="login_form" method="post" class="php-email-form">
          <div class="row gy-4">


            <div class="col-md-12 ">
              <label for="email">Email</label>
              <input type="email" class="form-control" name="email" placeholder="Your Email" required>
            </div>

            <div class="col-md-12">
              <label for="password">Password</label>
              <input type="password" class="form-control" name="password" placeholder="Password" required>
            </div>

            <div class="col-md-12 text-center">
              <button type="submit">Login</button>
            </div>

            <div class="col-md-12">
              <label for="info">Not registered? <a href="register.php"> Click Here</a></label>
            </div>

          </div>
        </form>

      </div>

    </div>

  </div>

</section><!-- End Contact Section -->
<?php include_once('footer.inc.php');?>
