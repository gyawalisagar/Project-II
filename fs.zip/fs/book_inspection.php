<div class="blog-comments">
  <div class="reply-form">
    <h4>Book for an inspection</h4>
    <form id="book_inspection">
      <div class="row">
        <p>Select Available Time Slots for inspection </p>
        <div class="col form-group">
          <!--loop this-->
          <?php
            $query="SELECT * FROM inspection_time WHERE property_id='$id'";
            $result = mysqli_query($mysqli,$query);
            while($row = mysqli_fetch_array($result)) {
              $inspection_id = $row['id'];
              $date = $row['date'];
              $time = $row['time'];
          ?>

          <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="inspection_time" value="<?php echo $inspection_id?>">
            <label class="form-check-label" for="inspection_time<?php echo $inspection_id?>"><?php echo $date . " - " . $time?></label>
          </div>

        <?php } ?>
          <!--end loop-->
        </div>
      </div>
      <div class="row">
        <div class="col form-group">
          <textarea name="comment" class="form-control" placeholder="Your Comment"></textarea>
        </div>
      </div>

      <input type="hidden" name="user_id" value="<?php echo $_SESSION['id']?>"/>

      <input type="submit" class="btn btn-primary" value="Book Inspection"/>

    </form>
  </div>

</div><!-- End blog comments -->
