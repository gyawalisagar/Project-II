<nav id="navbar" class="navbar">
  <ul>
    <li><a class="nav-link scrollto active" href="index.php">Home</a></li>
    <li><a class="nav-link scrollto" href="index.php#about">About</a></li>
    <li><a class="nav-link scrollto" href="index.php#team">Team</a></li>
    <li><a href="property.php">Properties</a></li>
    <li><a class="nav-link scrollto" href="index.php#contact">Contact</a></li>
    <?php if(!$isLoggedIn):?>
    <li><a href="login.php">Login</a></li>
    <?php else:
        if($_SESSION['user_type']=='agent'){
      ?>
      <li class="dropdown"><a href="#"><span>Agent</span> <i class="bi bi-chevron-down"></i></a>
        <ul>
          <li><a href="listproperty.php">List Property</a></li>
          <li><a href="editproperty.php">Edit Property</a></li>
          <li><a href="set_inspection.php">Set Inspection Time</a></li>
          <li><a href="admin/index.php">Admin Panel</a></li>
        </ul>
      </li>

    <?php } ?>
    <li><a href="profile.php">Profile</a></li>
    <li><a href="backend/logout.php">Logout</a></li>
    <?php endif;?>
  </ul>
  <i class="bi bi-list mobile-nav-toggle"></i>
</nav><!-- .navbar -->
