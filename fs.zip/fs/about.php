<!-- ======= About Section ======= -->
<section id="about" class="about">

  <div class="container" data-aos="fade-up">
    <div class="row gx-0">

      <div class="col-lg-6 d-flex flex-column justify-content-center" data-aos="fade-up" data-aos-delay="200">
        <div class="content">
          <h3>Who We Are</h3>
          <h2>We are an excellent real state company</h2>
          <p>
            We were established in 2021 and we are providing our service in strathfield and burwood only. We provide the best properties of different types to the the people and also help the sellers to sell their properties.
          </p>          
        </div>
      </div>

      <div class="col-lg-6 d-flex align-items-center" data-aos="zoom-out" data-aos-delay="200">
        <img src="assets/img/about.jpg" class="img-fluid" alt="">
      </div>

    </div>
  </div>

</section><!-- End About Section -->
