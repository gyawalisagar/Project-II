<?php include_once('header.inc.php');?>

  <main id="main">

    <?php
    require('backend/db_conn.php');
      if(isset($_GET['id'])){
        $id=mysqli_escape_string($mysqli,$_GET['id']);
        $query = "SELECT * FROM property WHERE id='$id'";
        $result = mysqli_query($mysqli, $query);
        $property = mysqli_fetch_assoc($result);
        $id=$property['id'];

    ?>

    <!-- ======= Breadcrumbs ======= -->
    <section class="breadcrumbs">
      <div class="container">

        <ol>
          <li><a href="index.php">Home</a></li>
          <li><a href="property.php">Properties</a></li>
          <li><?php echo $property['location']?></li>
        </ol>
        <h2><?php echo $property['location']?></h2>

      </div>
    </section><!-- End Breadcrumbs -->

    <!-- ======= Blog Single Section ======= -->
    <section id="blog" class="blog">
      <div class="container" data-aos="fade-up">

        <div class="row">

          <div class="col-lg-8 entries">

            <article class="entry entry-single">

              <div class="entry-img">
                <img src="<?php echo 'uploads/'.$property['photo']?>" alt="" class="img-fluid">
              </div>

              <h2 class="entry-title">
                <a> <?php echo $property['location']?></a>
                <h5 class="d-flex"><?php echo $property['property_type']." for ".$property['type']." - $". $property['price'] ?></h5>
              </h2>

              <div class="entry-meta">
                <ul>
                  <li class="d-flex align-items-center"><i class="bi bi-house"></i> <a href="property-single.php?id=<?php echo $id?>"><?php echo $property['bedroom']?> Bedroom</a></li>
                  <li class="d-flex align-items-center"><i class="bi bi-droplet"></i> <a href="property-single.php?id=<?php echo $id?>"><?php echo $property['bathroom']?> Bathroom</a></li>
                  <li class="d-flex align-items-center"><i class="bi bi-bricks"></i> <a href="property-single.php?id=<?php echo $id?>"><?php echo $property['parking']?> Parking</a></li>
                  <li class="d-flex align-items-center"><i class="bi bi-textarea"></i> <a href="property-single.php?id=<?php echo $id?>"><?php echo $property['area']." sq meter"?></a></li>
                  <li class="d-flex align-items-center"><i class="bi bi-clock"></i> <a href="property-single.php?id=<?php echo $id?>"><?php echo $property['list_date']?></a></li>
                </ul>
              </div>

              <div class="entry-content">

                <blockquote>
                  <p>
                    <?php echo $property['description'] ?>
                  </p>
                </blockquote>

              </div>

            </article><!-- End blog entry -->

            <?php if($isLoggedIn):
              if($_SESSION['user_type']=='client'){

                include("book_inspection.php");

              }else{ //if the user is an agent then display the avaible times and dates only

                //booking details by clients for inspection
                include('inspection_booking_sidebar.php');

                //set and delete inspection dates
                include("delete_inspection.php");


            }
          ?>

          <?php else: ?>

            <h4 class="text-danger">Please Login to book for an inspection </h4>

          <?php endif ?>

          </div><!-- End blog entries list -->

          <div class="col-lg-4">

            <!-- Side bar-->
            <?php include('recent_posts_sidebar.php')?>
            <!-- End Side bar-->

            <!-- Side bar-->
            <?php include('client_booking_sidebar.php')?>
            <!-- End Side bar-->


          </div><!-- End Blog sidebar -->

        </div>

      </div>
    </section><!-- End Blog Single Section -->
  <?php } ?>
  </main><!-- End #main -->

  <?php include_once('footer.inc.php');?>
