<?php include_once('header.inc.php');?>
<?php require('backend/db_conn.php');?>
  <main id="main">

    <!-- ======= Breadcrumbs ======= -->
    <section class="breadcrumbs">
      <div class="container">

        <ol>
          <li><a href="index.php">Home</a></li>
          <li>Properties</li>
        </ol>
        <h2>Properties</h2>

      </div>
    </section><!-- End Breadcrumbs -->


    <!-- ======= Normal Property Section ======= -->
    <section id="blog" class="blog">
      <div class="container" data-aos="fade-up">

        <div class="row">

          <div class="col-lg-8 entries">

            <?php

            $query="SELECT * FROM property ORDER BY list_date DESC";
            if(isset($_GET['search'])){
              $search = mysqli_escape_string($mysqli,$_GET['search']);
              $query="SELECT * FROM property WHERE concat(type,price,location,bedroom,bathroom,area,parking,list_date,description) LIKE '%$search%' ORDER BY list_date;";
            }
            
            if(isset($_POST['location'])){
              $type = mysqli_escape_string($mysqli,$_POST['type']);
              $property_type = mysqli_escape_string($mysqli,$_POST['property-type']);
              $location = mysqli_escape_string($mysqli,$_POST['location']);
              $min_price = mysqli_escape_string($mysqli,$_POST['min-price']);
              $max_price = mysqli_escape_string($mysqli,$_POST['max-price']);
              $min_bed = mysqli_escape_string($mysqli,$_POST['min-bed']);
              $max_bed = mysqli_escape_string($mysqli,$_POST['max-bed']);
              $min_bath = mysqli_escape_string($mysqli,$_POST['min-bath']);
              $max_bath = mysqli_escape_string($mysqli,$_POST['max-bath']);
              $min_park = mysqli_escape_string($mysqli,$_POST['min-park']);
              $max_park = mysqli_escape_string($mysqli,$_POST['max-park']);


              $query="SELECT * FROM property WHERE
                                                  type = '$type' AND
                                                  property_type = '$property_type' AND
                                                  location like '%$location%' AND
                                                  price >= '$min_price' AND
                                                  price <= '$max_price' AND
                                                  bedroom >= '$min_bed' AND
                                                  bedroom <= '$max_bed' AND
                                                  bathroom >= '$min_bath' AND
                                                  bathroom <= '$max_bath' AND
                                                  parking >= '$min_park' AND
                                                  parking <= '$max_park'
                                                  ";
            }
            $result = mysqli_query($mysqli,$query);
  					 while($row = mysqli_fetch_array($result)) {
              $id=$row["id"];
              $property_type=$row["property_type"];
              $type=$row["type"];
              $price=$row["price"];
              $location=$row["location"];
              $bedroom=$row["bedroom"];
              $bathroom=$row["bathroom"];
              $area=$row["area"];
              $parking=$row["parking"];
              $user_id=$row["user_id"];
              $photo=$row["photo"];
              $list_date=$row["list_date"];
              $description=$row["description"];
              $img_url = "uploads/".$photo;

              ?>

              <article class="entry">

                <div class="entry-img">
                  <img src="<?php echo $img_url?>" alt="" class="img-fluid">
                </div>

                <h2 class="entry-title">
                  <a href="property-single.php?id=<?php echo $id?>"><i class="bi bi-geo-fill"></i><?php echo $location?></a>
                  <h5 class="d-flex"><?php echo $property_type." for ".$type." - $". $price ?></h5>
                </h2>
                <div class="entry-meta">
                  <ul>
                    <li class="d-flex align-items-center"><i class="bi bi-house"></i> <a href="property-single.php?id=<?php echo $id?>"><?php echo $bedroom?> Bedroom</a></li>
                    <li class="d-flex align-items-center"><i class="bi bi-droplet"></i> <a href="property-single.php?id=<?php echo $id?>"><?php echo $bathroom?> Bathroom</a></li>
                    <li class="d-flex align-items-center"><i class="bi bi-bricks"></i> <a href="property-single.php?id=<?php echo $id?>"><?php echo $parking?> Parking</a></li>
                    <li class="d-flex align-items-center"><i class="bi bi-textarea"></i> <a href="property-single.php?id=<?php echo $id?>"><?php echo $area." sq meter"?></a></li>
                    <li class="d-flex align-items-center"><i class="bi bi-clock"></i> <a href="property-single.php?id=<?php echo $id?>"><?php echo $list_date?></a></li>

                  </ul>
                </div>

                <div class="entry-content">
                  <div class="read-more">
                    <a href="property-single.php?id=<?php echo $id?>">View Property</a>
                  </div>
                </div>

              </article><!-- End blog entry -->
            <?php
            }
            ?>

          </div><!-- End blog entries list -->

          <div class="col-lg-4">

            <div class="sidebar">

              <h3 class="sidebar-title">Search</h3>
              <div class="sidebar-item search-form">
                <form action="property.php" method="GET">
                  <input type="text" name="search" id="search">
                  <button type="submit"><i class="bi bi-search"></i></button>
                </form>
              </div>
            </div>

            <!--Sidebar-->
              <?php include('filter_search_sidebar.php')?>
            <!--End Sidebar-->

              <!--Sidebar-->
                <?php include('recent_posts_sidebar.php')?>
              <!--End Sidebar-->



          </div><!-- End blog sidebar -->

        </div>

      </div>
    </section><!-- End Normal Property Section -->


  </main><!-- End #main -->

<?php include_once('footer.inc.php');?>
